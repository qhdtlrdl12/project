package org.momento.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/reader/*")
public class DataReaderController {

	@GetMapping("/csvreader")
	public void csvReader() {}
	
	@PostMapping("/readerPost")
	public String csvReaderPost(RedirectAttributes rttr) {
		FileReader_1 csvReader = new FileReader_1();
		rttr.addFlashAttribute("csvread", csvReader.readCSV());
		
		return "redirect:/reader/csvreader";
	}
	 
}
