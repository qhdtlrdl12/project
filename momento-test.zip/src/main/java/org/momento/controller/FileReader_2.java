package org.momento.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

public class FileReader_2 {
	public String title;
	public FileReader_2(String test) {
		 title = test;
		 
		 return;
	}
	 public List<List<String>> readCSV() {
	        List<List<String>> csvList = new ArrayList<List<String>>();
	        File csv = new File("C://test/test3.csv");
	        
	        BufferedReader br = null;
	        String line = "";
	        
//	        String name = "";
	        int p = 0;
	        try {
	           
	            br = new BufferedReader(new FileReader(csv));
	            
	            while ((line = br.readLine()) != null) { // readLine()은 파일에서 개행된 한 줄의 데이터를 읽어온다.
	               
	               List<String> aLine = new ArrayList<String>();
	               
	               String[] lineArr = line.split(","); // 파일의 한 줄을 ,로 나누어 배열에 저장 후 리스트로 변환한다.
	               if(p == 0) {
	                  int i=0;
	                      for(String s : lineArr) {
	                      System.out.println(s);
	                      if(i==0) {
	                         lineArr[i] = "create "+ title +" value('"+lineArr[i]+"'";
	                      }
	                      else if(i == lineArr.length-1) {
	                         lineArr[i] ="'"+lineArr[i]+"')";
	                      }
	                      else {
	                         lineArr[i] = "'"+lineArr[i]+"'";
	                      }
	                      System.out.println(lineArr[i]);
	                            
	                      i++;      
	                   }
	                    aLine = Arrays.asList(lineArr);
	                    csvList.add(aLine);
	                    p++;
	                    continue;
	               }
	               
	               if(p != 0) {
	                  int i=0;
	               for(String s : lineArr) {
	                  
	                  if(i==0) {
	                     lineArr[i] = "insert into "+ title +" value('"+lineArr[i]+"'";
	                  }
	                  else if(i == lineArr.length-1) {
	                     lineArr[i] ="'"+lineArr[i]+"')";
	                  }
	                  else {
	                     lineArr[i] = "'"+lineArr[i]+"'";
	                  }
	                  System.out.println(lineArr[i]);
	                        i++;
	               }
	               }
	                aLine = Arrays.asList(lineArr);
	                csvList.add(aLine);
	               }
	            
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                if (br != null) { 
	                    br.close(); // 사용 후 BufferedReader를 닫아준다.
	                }
	            } catch(IOException e) {
	                e.printStackTrace();
	            }
	        }
	        return csvList;
	    }
}
