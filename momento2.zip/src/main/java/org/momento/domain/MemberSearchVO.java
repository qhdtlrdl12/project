package org.momento.domain;

import lombok.Data;

@Data
public class MemberSearchVO {

	private String userName;
	private String phone;
}
