package org.momento.domain;

public class SomeField {

}
