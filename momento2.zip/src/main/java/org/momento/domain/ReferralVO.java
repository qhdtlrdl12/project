package org.momento.domain;

import lombok.Data;

@Data
public class ReferralVO {

	private String user_id;
	private Long bno;
	
}
